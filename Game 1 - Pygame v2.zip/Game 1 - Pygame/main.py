import pygame
import time
import random

pygame.init()

WIDTH, HEIGHT = 1280, 720
FPS = 60
PLAYER_WIDTH, PLAYER_HEIGHT = 25, 25
COLOR_BG = (3, 252, 94)
COLOR_WALL = (255, 0, 0)
COLOR_GOAL = (255, 255, 0)
COLOR_TEXT = (0, 0, 255)
COLOR_TEXT_DEATH = (128, 11, 11)

pygame.mixer.init()
pygame.mixer.music.load("audio/bg.mp3")  
pygame.mixer.music.play(-1)

death_sound = pygame.mixer.Sound("audio/death.mp3")
win_sound = pygame.mixer.Sound("audio/win.mp3")

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Game 1")
clock = pygame.time.Clock()

background = pygame.image.load("images/background.png")
background = pygame.transform.scale(background, (WIDTH, HEIGHT))

wall_texture = pygame.image.load("images/wall_texture.png")
wall_texture = pygame.transform.scale(wall_texture, (50, 50))

goal_texture = pygame.image.load("images/goal_texture.png")


player_images = {
    "idle": pygame.image.load("images/player.png"),
    "up": pygame.image.load("images/player_up.png"),
    "down": pygame.image.load("images/player_down.png"),
    "left": pygame.image.load("images/player_left.png"),
    "right": pygame.image.load("images/player_right.png"),
    "blink": pygame.image.load("images/player_blink.png"),
    "blink2": pygame.image.load("images/player_blink2.png")
}

for key in player_images:
    player_images[key] = pygame.transform.scale(player_images[key], (PLAYER_WIDTH, PLAYER_HEIGHT))

pygame.display.set_icon(player_images["idle"])

font = pygame.font.Font(None, 36)

def generate_labyrinth(player_rect, goal_rect):
    walls = []
    for _ in range(100):
        x = random.randint(0, WIDTH - 20)
        y = random.randint(0, HEIGHT - 20)
        w = random.randint(40, 100)
        h = random.randint(40, 100)
        
        wall_rect = pygame.Rect(x, y, w, h)
        
        if player_rect.colliderect(wall_rect) or goal_rect.colliderect(wall_rect):
            continue
        
        if random.choice([True, False]):
            walls.append(pygame.Rect(x, y, w, 20))
        else:
            walls.append(pygame.Rect(x, y, 20, h))
    
    return walls

def reset_game():
    player_x, player_y = WIDTH // 2, HEIGHT // 2
    player_rect = pygame.Rect(player_x, player_y, PLAYER_WIDTH, PLAYER_HEIGHT)
    goal = pygame.Rect(1100, 350, 50, 50)
    walls = generate_labyrinth(player_rect, goal)
    return player_x, player_y, walls

player_x, player_y, walls = reset_game()
player_speed = 15
player_img = player_images["idle"]
goal = pygame.Rect(1100, 350, 50, 50)
player_direction = None
direction_time = 0
idle_time = time.time()

win_count = 0
death_count = 0

running = True
while running:
    clock.tick(FPS)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    moving = False
    new_x, new_y = player_x, player_y
    
    if keys[pygame.K_a]:
        new_x -= player_speed
        if player_direction != "left" or time.time() - direction_time > 1:
            player_img = player_images["left"]
            player_direction = "left"
            direction_time = time.time()
        moving = True
    if keys[pygame.K_d]:
        new_x += player_speed
        if player_direction != "right" or time.time() - direction_time > 1:
            player_img = player_images["right"]
            player_direction = "right"
            direction_time = time.time()
        moving = True
    if keys[pygame.K_w]:
        new_y -= player_speed
        if player_direction != "up" or time.time() - direction_time > 1:
            player_img = player_images["up"]
            player_direction = "up"
            direction_time = time.time()
        moving = True
    if keys[pygame.K_s]:
        new_y += player_speed
        if player_direction != "down" or time.time() - direction_time > 1:
            player_img = player_images["down"]
            player_direction = "down"
            direction_time = time.time()
        moving = True
    if keys[pygame.K_m]:
        pygame.mixer.music.stop()
    if keys[pygame.K_k]:
        pygame.mixer.music.play(-1)
    
    if not moving:
        if time.time() - idle_time > 1:
            player_img = player_images["idle"]
    
    player_rect = pygame.Rect(new_x, new_y, PLAYER_WIDTH, PLAYER_HEIGHT)
    
    if not any(player_rect.colliderect(wall) for wall in walls) and 0 < new_x < WIDTH - PLAYER_WIDTH and 0 < new_y < HEIGHT - PLAYER_HEIGHT:
        player_x, player_y = new_x, new_y
        idle_time = time.time()
    else:
        player_x, player_y = WIDTH // 2, HEIGHT // 2
        death_count += 1

    if player_rect.colliderect(goal):
        win_sound.play()
        win_count += 1
        start_time = time.time()
        while time.time() - start_time < 3:
            screen.fill(COLOR_BG)
            goal_img = pygame.transform.scale(goal_texture, (goal.width, goal.height))
            screen.blit(goal_img, (goal.x, goal.y))
            # pygame.draw.rect(screen, COLOR_GOAL, goal)
            for wall in walls:
                # pygame.draw.rect(screen, COLOR_WALL, wall)
                wall_img = pygame.transform.scale(wall_texture, (wall.width, wall.height))
                screen.blit(wall_img, (wall.x, wall.y))

            player_img = player_images["blink"] if int((time.time() - start_time) * 2) % 2 == 0 else player_images["idle"]
            screen.blit(player_img, (player_x, player_y))
            
            win_text = font.render(f"Wins: {win_count} Deaths: {death_count}", True, COLOR_TEXT)
            screen.blit(win_text, (WIDTH // 2 - win_text.get_width() // 2, 10))
            
            pygame.display.flip()
            clock.tick(FPS)
        player_x, player_y, walls = reset_game()

    if death_count >= 100:
        pygame.mixer.music.stop()
        death_sound.play()
        start_time = time.time()
        while time.time() - start_time < 3:
            screen.fill(COLOR_BG)
            goal_img = pygame.transform.scale(goal_texture, (goal.width, goal.height))
            screen.blit(goal_img, (goal.x, goal.y))
            # pygame.draw.rect(screen, COLOR_GOAL, goal)
            # pygame.draw.rect(screen, COLOR_GOAL, goal)
            for wall in walls:
                # pygame.draw.rect(screen, COLOR_WALL, wall)
                wall_img = pygame.transform.scale(wall_texture, (wall.width, wall.height))
                screen.blit(wall_img, (wall.x, wall.y))
            
            player_img = player_images["blink2"] if int((time.time() - start_time) * 2) % 2 == 0 else player_images["idle"]
            screen.blit(player_img, (player_x, player_y))
            
            win_text = font.render(f"Wins: {win_count} Deaths: {death_count}", True, COLOR_TEXT_DEATH)
            screen.blit(win_text, (WIDTH // 2 - win_text.get_width() // 2, 10))
            
            pygame.display.flip()
            clock.tick(FPS)
        running = False

    # screen.fill(COLOR_BG)
    screen.blit(background, (0,0))
    # pygame.draw.rect(screen, COLOR_GOAL, goal)
    goal_img = pygame.transform.scale(goal_texture, (goal.width, goal.height))
    screen.blit(goal_img, (goal.x, goal.y))
    # pygame.draw.rect(screen, COLOR_GOAL, goal)
    for wall in walls:
        # pygame.draw.rect(screen, COLOR_WALL, wall)
        wall_img = pygame.transform.scale(wall_texture, (wall.width, wall.height))
        screen.blit(wall_img, (wall.x, wall.y))
    
    pygame.draw.rect(screen, COLOR_WALL, pygame.Rect(0, 0, WIDTH, 20))
    pygame.draw.rect(screen, COLOR_WALL, pygame.Rect(0, HEIGHT - 20, WIDTH, 20))
    pygame.draw.rect(screen, COLOR_WALL, pygame.Rect(0, 0, 20, HEIGHT))
    pygame.draw.rect(screen, COLOR_WALL, pygame.Rect(WIDTH - 20, 0, 20, HEIGHT))
    
    text_color = COLOR_TEXT_DEATH if death_count >= 100 else COLOR_TEXT
    win_text = font.render(f"Wins: {win_count} Deaths: {death_count}", True, text_color)
    screen.blit(win_text, (WIDTH // 2 - win_text.get_width() // 2, 10))
    
    screen.blit(player_img, (player_x, player_y))
    pygame.display.flip()

pygame.quit()